/* A Bison parser, made by GNU Bison 3.7.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_SRC_PARSER_TAB_H_INCLUDED
# define YY_YY_SRC_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    STRING_LITERAL = 258,          /* STRING_LITERAL  */
    BASE_LITERAL = 259,            /* BASE_LITERAL  */
    ID = 260,                      /* ID  */
    INT_LITERAL = 261,             /* INT_LITERAL  */
    TYPE_DNA_KW = 262,             /* TYPE_DNA_KW  */
    TYPE_RNA_KW = 263,             /* TYPE_RNA_KW  */
    GENE = 264,                    /* GENE  */
    EXPRESS = 265,                 /* EXPRESS  */
    REPORT = 266,                  /* REPORT  */
    WHEN = 267,                    /* WHEN  */
    OTHERWISE = 268,               /* OTHERWISE  */
    OTHERWISE_WHEN = 269,          /* OTHERWISE_WHEN  */
    STOP = 270,                    /* STOP  */
    CYCLE = 271,                   /* CYCLE  */
    ACROSS = 272,                  /* ACROSS  */
    FROM = 273,                    /* FROM  */
    TO = 274,                      /* TO  */
    GROW = 275,                    /* GROW  */
    UNTIL = 276,                   /* UNTIL  */
    HALT = 277,                    /* HALT  */
    SKIP = 278,                    /* SKIP  */
    BOTH = 279,                    /* BOTH  */
    EITHER = 280,                  /* EITHER  */
    LACKS = 281,                   /* LACKS  */
    BOUND = 282,                   /* BOUND  */
    UNBOUND = 283,                 /* UNBOUND  */
    FUSE = 284,                    /* FUSE  */
    HEAD = 285,                    /* HEAD  */
    TAIL = 286,                    /* TAIL  */
    TRANSCRIBE = 287,              /* TRANSCRIBE  */
    ARROW = 288,                   /* ARROW  */
    EQ = 289,                      /* EQ  */
    LE = 290,                      /* LE  */
    GE = 291,                      /* GE  */
    LT = 292,                      /* LT  */
    GT = 293,                      /* GT  */
    TILDE = 294,                   /* TILDE  */
    AT = 295,                      /* AT  */
    HASH = 296,                    /* HASH  */
    LPAREN = 297,                  /* LPAREN  */
    RPAREN = 298,                  /* RPAREN  */
    COMMA = 299                    /* COMMA  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 25 "src/parser.y"

    char* str_val;
    long long int_val;
    int data_type;
    class ExprAST* expr;
    class StmtAST* stmt;
    class GeneDeclAST* gene;
    std::vector<class StmtAST*>* stmt_list;
    std::vector<class ExprAST*>* expr_list;
    std::vector<struct ParamDecl>* param_list;
    std::vector<struct CondBranchRaw>* branch_list;

#line 121 "src/parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;
int yyparse (void);

#endif /* !YY_YY_SRC_PARSER_TAB_H_INCLUDED  */
